package com.example.baguiowastesorter

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class ResidualActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_residual)

        // Add more detailed content on residual waste if needed
    }
}
