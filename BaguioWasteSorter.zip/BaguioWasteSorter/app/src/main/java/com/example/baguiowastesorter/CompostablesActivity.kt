package com.example.baguiowastesorter

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class CompostablesActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_compostables)

        // Add more detailed content on compostables if needed
    }
}


