package com.example.baguiowastesorter

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Show a simple notification/announcement when the app starts
        showAnnouncementDialog()

        // Input and button functionality for product details
        val searchButton: Button = findViewById(R.id.search_button)
        val productInput: EditText = findViewById(R.id.product_input)
        val resultText: TextView = findViewById(R.id.result_text)

        searchButton.setOnClickListener {
            val product = productInput.text.toString().trim().lowercase()
            val disposalMethod = getDisposalMethod(product)
            resultText.text = disposalMethod
        }
    }

    // Function to show the announcement dialog
    private fun showAnnouncementDialog() {
        val announcement = "Important: There will be a delay in garbage collection this week due to local holidays."

        // Create an AlertDialog to display the announcement
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Announcement")
        builder.setMessage(announcement)

        // Add an OK button to dismiss the dialog
        builder.setPositiveButton("OK") { dialog, _ ->
            dialog.dismiss() // Close the dialog when the user clicks OK
        }

        // Show the dialog
        builder.show()
    }

    // Function to check the disposal method for a given product
    private fun getDisposalMethod(product: String): String {
        // Define lists of items in different waste categories
        val recyclables = listOf("plastic bottle", "paper", "aluminum can", "glass bottle", "cardboard")
        val compostables = listOf("food waste", "fruit peel", "vegetable waste", "eggshells", "coffee grounds")
        val residual = listOf("diaper", "styrofoam", "ceramics", "broken glass")
        val eWaste = listOf("phone", "laptop", "battery", "television", "printer")

        return when {
            recyclables.contains(product) -> "This item is recyclable."
            compostables.contains(product) -> "This item is compostable."
            residual.contains(product) -> "This item belongs to residual waste."
            eWaste.contains(product) -> "This item requires special handling (e-waste)."
            else -> "Item not found. Please check with local waste management policies."
        }
    }
}
